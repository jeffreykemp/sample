=== Audio Shortcode ===
Contributors: jeffreykemp
Tags: audio shortcode mp3
Requires at least: 3.8.1
Tested up to: 4.0.0
Stable tag: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Audio Shortcode uses a [mpeg] shortcode to add an HTML5 audio player.

== Description ==

Audio Shortcode uses a `[mpeg]` shortcode to add an HTML5 audio player.

Usage example: `[mpeg]https://archive.org/download/testmp3testfile/mpthreetest.mp3[/mpeg]`

== Installation ==

1. Upload `audio-shortcode.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use the `[mpeg]url[/mpeg]` syntax in a post or a page to add the audio player.

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

= 0.1 =
* Initial version.

== Upgrade Notice ==

= 0.1 =
* Initial version.
