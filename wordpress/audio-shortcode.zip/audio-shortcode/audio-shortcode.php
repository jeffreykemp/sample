<?php
/*
Plugin Name: Audio Shortcode
Plugin URI:
Description: This plugin uses a shortcode to create an HTML5 audio player.
Author: jeffreykemp
Version: 0.1
Author URI: https://jk64.com
License: GPL2
*/

class JK64_Audio_Shortcode {
	public function __construct() {
		 add_shortcode( 'mpeg', array( $this, 'wp_audio_shortcode' ) );
	}

	public function wp_audio_shortcode( $atts, $content = null ) {
    $url = esc_url($content);
    $atts = shortcode_atts(
          array(
            'type' => 'mpeg'
          ), $atts, 'audio-shortcode');
    return '<audio controls><source src="' . $url . '" type="audio/' . $atts['type'] . '"><a href="' . $url . '">Download </a></audio>';
	}
}

$jk64_audio_shortcode = new JK64_Audio_Shortcode();
?>