<?php
/*
Plugin Name: Bible Link
Plugin URI:
Description: This plugin uses a shortcode to automatically link to verses on http://bible.com
Author: chaselivingston
Version: 0.2 - Jeff Kemp - customised for NKJV; fixed issue with book names no longer accepted by bible.com
Author URI: http://chaselivingston.me
License: GPL2
*/

class CEL_Bible_Link {
	public function __construct() {
		 add_shortcode( 'bible', array( $this, 'wp_biblelink_shortcode' ) );
	}

	public function wp_biblelink_shortcode( $atts, $content = null ) {
        $atts = shortcode_atts(
          array(
            'version' => '114', //NKJV by default
            'ref' => $content //default to content if not specified directly
          ), $atts, 'bible');
		// book urls which don't map from the first 3 characters of the book name
		$books = array(
			"judges" => "jdg",
			"songofsolomon" => "sng",
			"ezekiel" => "ezk",
			"joel" => "jol",
			"nahum" => "nam",
			"mark" => "mrk",
			"john" => "jhn",
			"philippians" => "php",
			"philemon" => "phm",
			"james" => "jas",
			"1john" => "1jn",
			"2john" => "2jn",
			"3john" => "3jn"
		);
		// first token is expected to be the book name (or possibly a book number, e.g. "2 corinthians")
		$book = strtolower( strtok( $atts['ref'], ' ' ) );
        if ( in_array($book, array("1","2","3")) ) {
			//append the book name directly, e.g. "1chronicles"
        	$book .= strtolower( strtok(' ') );
        } elseif ( in_array($book, array("i","ii","iii")) ) {
			//convert "iii" to "3" etc, then append the book name directly, e.g "3john"
        	$book = strlen($book) . strtolower( strtok(' ') );
        }
        $book = rtrim($book, '.');
		// next token is expected to be the chapter
		$chapter = strtok(':');
		// next token is expected to be the verse (or verse range)
        $verse = strtok(':');
		// convert book name to the url shortcode (abbreviation) expected by bible.com
		if ( array_key_exists($book,$books) ) {
			$book = $books[$book];
		} else {
			// all others correspond to the first 3 characters of the book name
			$book = substr($book,0,3);
		}
		$url = 'https://bible.com/bible/' . $atts['version'] . '/' . $book . '.' . $chapter . '.' . $verse;
		return '<a href="' . esc_url($url) . ' " target="_blank">'  . esc_html($content) . '</a>';
	}
}

$cel_bible_link = new CEL_Bible_Link();
?>